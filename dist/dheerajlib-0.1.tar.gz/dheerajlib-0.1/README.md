# My Library

This is a simple Python library that provides a function to add two numbers.

## Installation

You can install this library using pip:

```bash
pip install dheerajlib